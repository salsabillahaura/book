package com.example.loginbooka;

import static com.example.loginbooka.app.AppController.TAG;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.example.loginbooka.app.AppController;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;

import com.example.loginbooka.databinding.ActivityBerandaUsersBinding;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class BerandaUsers extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    Menu menuView;
    TextView day;
    AppCompatButton l1,l2,l3,l4;
    String s1,s2,s3,s4,nama,n1,n2,n3,n4,id1,id2,id3,id4;
    private String url = Server.URL + "/APIAllLoker";
    ProgressDialog pDialog;
    SharedPreferences sharedpreferences;
    public static final String TAG_USERNAME = "name";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda_users);

        day = findViewById(R.id.BUDay);
        l1 = findViewById(R.id.BUL1);
        l2 = findViewById(R.id.BUL2);
        l3 = findViewById(R.id.BUL3);
        l4 = findViewById(R.id.BUL4);

        Toolbar toolbar = findViewById(R.id.toolbarBerandaUsers);

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setItemIconTintList(null);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        DrawerLayout drawer1 = (DrawerLayout) findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer1.addDrawerListener(toggle);
        toggle.syncState();
        toggle.getDrawerArrowDrawable().setColor(getResources().getColor(R.color.black));

        navigationView.bringToFront();
        View hView =  navigationView.getHeaderView(0);

        menuView= navigationView.getMenu();

        DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy");
        String date = df.format(Calendar.getInstance().getTime());

        day.setText(date);

        sharedpreferences = getSharedPreferences(SignInActivity.my_shared_preferences, Context.MODE_PRIVATE);

        nama = getIntent().getStringExtra(TAG_USERNAME);

        ViewData();

        day.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewData();
            }
        });

        l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(s1.equals("1")){
                    Intent intent = new Intent(BerandaUsers.this, LockerL1Activity.class);
                    intent.putExtra("LOKER",n1);
                    intent.putExtra("NO",id1);
                    intent.putExtra("NAMA",nama);
                    startActivity(intent);
                }else {
                    Toast.makeText(BerandaUsers.this,"Maaf Loker Terpakai",Toast.LENGTH_LONG).show();
                }
            }
        });

        l2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(s2.equals("1")){
                    Intent intent = new Intent(BerandaUsers.this, LockerL1Activity.class);
                    intent.putExtra("LOKER",n2);
                    intent.putExtra("NO",id2);
                    intent.putExtra("NAMA",nama);
                    startActivity(intent);
                }else {
                    Toast.makeText(BerandaUsers.this,"Maaf Loker Terpakai",Toast.LENGTH_LONG).show();
                }
            }
        });

        l3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(s3.equals("1")){
                    Intent intent = new Intent(BerandaUsers.this, LockerL1Activity.class);
                    intent.putExtra("LOKER",n3);
                    intent.putExtra("NO",id3);
                    intent.putExtra("NAMA",nama);
                    startActivity(intent);
                }else {
                    Toast.makeText(BerandaUsers.this,"Maaf Loker Terpakai",Toast.LENGTH_LONG).show();
                }
            }
        });

        l4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(s4.equals("1")){
                    Intent intent = new Intent(BerandaUsers.this, LockerL1Activity.class);
                    intent.putExtra("LOKER",n4);
                    intent.putExtra("NO",id4);
                    intent.putExtra("NAMA",nama);
                    startActivity(intent);
                }else {
                    Toast.makeText(BerandaUsers.this,"Maaf Loker Terpakai",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void ViewData() {

        //swipe.setRefreshing(true);
        // membuat request JSON
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Check ...");
        showDialog();

        StringRequest eventoReq = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        hideDialog();
                        Log.d(TAG, response.toString());
                        try{
                            JSONArray j= new JSONArray(response);

                            // Parsea json
                            for (int i = 0; i < j.length(); i++) {
                                try {
                                    JSONObject obj = j.getJSONObject(i);

                                    if(obj.getString("nomer_loker").equals("01")){
                                        if(obj.getString("status_loker").equals("1")){
                                            l1.setBackgroundResource(R.drawable.button_open_locker_green);
                                            s1 = "1";
                                            n1 = obj.getString("nama_loker");
                                            id1 = obj.getString("id");
                                        }else {
                                            l1.setBackgroundResource(R.drawable.button_close_locker_red);
                                            s1 = "0";
                                        }
                                    }

                                    if(obj.getString("nomer_loker").equals("02")){
                                        if(obj.getString("status_loker").equals("1")){
                                            l2.setBackgroundResource(R.drawable.button_open_locker_green);
                                            s2 = "1";
                                            n2 = obj.getString("nama_loker");
                                            id2 = obj.getString("id");
                                        }else {
                                            l2.setBackgroundResource(R.drawable.button_close_locker_red);
                                            s2 = "0";
                                        }
                                    }

                                    if(obj.getString("nomer_loker").equals("03")){
                                        if(obj.getString("status_loker").equals("1")){
                                            l3.setBackgroundResource(R.drawable.button_open_locker_green);
                                            s3 = "1";
                                            n3 = obj.getString("nama_loker");
                                            id3 = obj.getString("id");
                                        }else {
                                            l3.setBackgroundResource(R.drawable.button_close_locker_red);
                                            s3 = "0";
                                        }
                                    }

                                    if(obj.getString("nomer_loker").equals("04")){
                                        if(obj.getString("status_loker").equals("1")){
                                            l4.setBackgroundResource(R.drawable.button_open_locker_green);
                                            s4 = "1";
                                            n4 = obj.getString("nama_loker");
                                            id4 = obj.getString("id");
                                        }else {
                                            l4.setBackgroundResource(R.drawable.button_close_locker_red);
                                            s4 = "0";
                                        }
                                    }


                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                hideDialog();
            }
        }){
            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                return params;
            }
        };

        // Añade la peticion a la cola
        AppController.getInstance().addToRequestQueue(eventoReq);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent intent = new Intent(this, BerandaUsers.class);
            startActivity(intent);
            finish();
//            Toast.makeText(BerandaUsers.this,"home pencet",Toast.LENGTH_LONG).show();
        }
        else if (id == R.id.nav_info_app) {
            Intent intent = new Intent(this, UserTentangAplikasiActivity.class);
            startActivity(intent);
            finish();
//            Toast.makeText(BerandaUsers.this,"users pencet",Toast.LENGTH_LONG).show();
        }
        else if (id == R.id.nav_about_us) {
            Intent intent = new Intent(this, UserTentangKamiActivity.class);
            startActivity(intent);
            finish();
//            Toast.makeText(BerandaUsers.this,"users pencet",Toast.LENGTH_LONG).show();
        }
        else if (id == R.id.BU_logout) {

            sharedpreferences = getSharedPreferences("login",
                    Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedpreferences.edit();
            editor.clear();
            editor.apply();

            Intent intent = new Intent(this, SignInActivity.class);
            startActivity(intent);
            finish();


        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

    @Override
    public void onBackPressed() {
        Intent setIntent = new Intent(this, BerandaUsers.class);
        finish();
        startActivity(setIntent);
    }

}