package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.util.SizeF;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.loginbooka.app.AppController;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterTamuActivity extends AppCompatActivity {

    private EditText editTextName, editTextEmail, editTextInstitusi, editTextPassword, editTextConfirmPassword;

    private Button buttonRegister;

    Intent intent;

    int success;
    ConnectivityManager conMgr;

    private String url = Server.URL + "/APIRegister";

    private static final String TAG = RegisterTamuActivity.class.getSimpleName();

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    String tag_json_obj = "json_obj_req";
    ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_tamu);

//       Toast.makeText(RegisterTamuActivity.this, "You can register", Toast.LENGTH_SHORT).show();

        editTextName = findViewById(R.id.edit_txt_nama_tamu);
        editTextEmail = findViewById(R.id.edit_txt_email_tamu);
        editTextInstitusi = findViewById(R.id.edit_txt_institusi_tamu);
        editTextPassword = findViewById(R.id.edit_txt_password_tamu);
        editTextConfirmPassword = findViewById(R.id.edit_txt_confirm_password_tamu);

        buttonRegister = findViewById(R.id.btn_register);

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                String textName = editTextName.getText().toString();
                String textInstitusi = editTextInstitusi.getText().toString();
                String textEmail = editTextEmail.getText().toString();
                String textPassword = editTextPassword.getText().toString();
                String textConfirmPassword = editTextConfirmPassword.getText().toString();
//                if (TextUtils.isEmpty(textName)) {
//                    Toast.makeText(RegisterTamuActivity.this, "Silakan masukkan Nama Anda.", Toast.LENGTH_SHORT).show();
//                    editTextName.setError("Nama wajib diisi");
//                    editTextName.requestFocus();
//                } else if (TextUtils.isEmpty(textEmail)) {
//                    Toast.makeText(RegisterTamuActivity.this, "Silakan masukkan Email Anda", Toast.LENGTH_SHORT).show();
//                    editTextEmail.setError("Email wajib diisi");
//                    editTextEmail.requestFocus();
//                } else if (TextUtils.isEmpty(textInstitusi)) {
//                    Toast.makeText(RegisterTamuActivity.this, "Silakan masukkan Institusi Anda", Toast.LENGTH_SHORT).show();
//                    editTextInstitusi.setError("Institusi wajib diisi");
//                    editTextInstitusi.requestFocus();
//                } else if (TextUtils.isEmpty(textPassword)) {
//                    Toast.makeText(RegisterTamuActivity.this, "Silakan masukkan Kata Sandi Anda", Toast.LENGTH_SHORT).show();
//                    editTextPassword.setError("Kata Sandi wajib diisi");
//                    editTextPassword.requestFocus();
//                } else if (textPassword.length() < 6) {
//                    Toast.makeText(RegisterTamuActivity.this, "Kata Sandi harus setidaknya 6 digit", Toast.LENGTH_SHORT).show();
//                    editTextPassword.setError("Kata Sandi wajib diisi");
//                    editTextPassword.requestFocus();
//                } else if (TextUtils.isEmpty(textConfirmPassword)) {
//                    Toast.makeText(RegisterTamuActivity.this, "Silakan konfirmasi Kata Sandi Anda", Toast.LENGTH_SHORT).show();
//                    editTextConfirmPassword.setError("Konfirmasi Kata Sandi wajib diisi");
//                    editTextConfirmPassword.requestFocus();
//                } else if (!textPassword.equals(textConfirmPassword)) {
//                    Toast.makeText(RegisterTamuActivity.this, "Masukkan Kata Sandi yang sama", Toast.LENGTH_SHORT).show();
//                    editTextConfirmPassword.setError("Konfirmasi Kata Sandi wajib diisi");
//                    editTextConfirmPassword.requestFocus();
//
//                    editTextPassword.clearComposingText();
//                    editTextConfirmPassword.clearComposingText();
//                } else {
                    checkRegister(textName, textPassword, textInstitusi, textEmail, textConfirmPassword);
//                }

            }
        });


    }

    private void checkRegister( final String textInstitusi,
                                final String textEmail,
                                final String textName,
                                final String textPassword,
                                final String textConfirmPassword){
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Register ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Register Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    success = jObj.getInt(TAG_SUCCESS);

                    // Check for error node in json
                    if (success == 1) {

                        intent = new Intent(RegisterTamuActivity.this, SignInActivity.class);
                        finish();
                        startActivity(intent);

                    } else {
                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

                hideDialog();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("name", textInstitusi);
                params.put("institusi", textName);
                params.put("email", textPassword);
                params.put("password", textEmail);
//                params.put("confirm_password", textConfirmPassword);

                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_json_obj);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }


}