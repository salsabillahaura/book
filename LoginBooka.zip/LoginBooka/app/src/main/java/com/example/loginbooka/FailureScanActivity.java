package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

public class FailureScanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.activity_failure_scan);

        // langsung pindah ke MainActivity atau activity lain
        // begitu memasuki splash screen ini
        Thread timer=new Thread()
        {
            public void run() {
                try {
                    sleep(2000);
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                finally
                {
                    Intent i=new Intent(FailureScanActivity.this, LockersActivity.class);
                    finish();
                    startActivity(i);
                }
            }
        };
        timer.start();
    }

}