package com.example.loginbooka;

import java.util.List;

public interface FetchDataListenerPresensi {
    public void onFetchComplete(List<ApplicationPresensi> data);
    public void onFetchFailure(String msg);
}
