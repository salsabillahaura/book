package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Objects;

public class LockerL1Activity extends AppCompatActivity implements View.OnClickListener{
    private IntentIntegrator intentIntegrator;
    private Button btn_rent_a_locker_l1;
    private static final String TAG_LOKER = "loker";
    private String KEY_NAME = "NAMA";
    private String KEY_NO = "NO";
    private String KEY_LOKER = "LOKER";
    AppCompatButton Bloker;
    TextView Nloker;

    String n = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locker_l1);
        Bloker = findViewById(R.id.UCLoker);
        Nloker = findViewById(R.id.txt_header_1_locker_L1);
        Bundle extras = getIntent().getExtras();
        String nama = extras.getString(KEY_NAME);
        String no = extras.getString(KEY_NO);
        String loker = extras.getString(KEY_LOKER);
        btn_rent_a_locker_l1 = (Button)findViewById(R.id.btn_rent_a_locker_l1);

        Bloker.setText("L"+no);
        Nloker.setText("Locker-"+no);

        btn_rent_a_locker_l1.setOnClickListener(this);
//        btn_rent_a_locker_l1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(LockerL1Activity.this, UserCheckLockerActivity.class);
//                intent.putExtra(KEY_NAME,nama);
//                intent.putExtra(KEY_NO,no);
//                intent.putExtra(KEY_LOKER,loker);
//                finish();
//                startActivity(intent);
//                Toast.makeText(LockerL1Activity.this,nama,Toast.LENGTH_LONG).show();
//            }
//        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        Bundle extras = getIntent().getExtras();
        String nama = extras.getString(KEY_NAME);
        String no = extras.getString(KEY_NO);
        String lok = extras.getString(KEY_LOKER);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "Hasil tidak ditemukan",
                        Toast.LENGTH_SHORT).show();
            } else {
                try {
                    JSONObject object = new JSONObject(result.getContents());
                    String loker = object.getString(TAG_LOKER);
                    String key = "";
//                    Toast.makeText(this, loker, Toast.LENGTH_SHORT).show();
                    if(no.equals("1")){
                        key = "l1pnj";
                    } else if(no.equals("2")){
                        key = "l2pnj";
                    } else if(no.equals("3")){
                        key = "l3pnj";
                    } else if(no.equals("4")){
                        key = "l4pnj";
                    }
                    if(Objects.equals(loker, key)){
                        Intent i=new Intent(this,UserCheckLockerActivity.class);
                        i.putExtra(KEY_NAME,nama);
                        i.putExtra(KEY_NO,no);
                        i.putExtra(KEY_LOKER,lok);
                        finish();
                        startActivity(i);
//                        Toast.makeText(this, nama, Toast.LENGTH_SHORT).show();
                    }else{
                        Intent i=new Intent(this,FailureScanActivity.class);
                        finish();
                        startActivity(i);
//                        Toast.makeText(this, "loker tidak sesuai", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    // jika format encoded tidak sesuai maka hasil
                    // ditampilkan ke toast
                    Toast.makeText(this, result.getContents(), Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void onClick(View v) {         // inisialisasi IntentIntegrator(scanQR)
        intentIntegrator = new IntentIntegrator(this);
        intentIntegrator.initiateScan();
    }
}