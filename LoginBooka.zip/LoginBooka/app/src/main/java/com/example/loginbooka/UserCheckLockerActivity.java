package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.loginbooka.app.AppController;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class UserCheckLockerActivity extends AppCompatActivity {
    Button cek;
    String lok, name, no;
    Intent intent;
    AppCompatButton Bloker;
    TextView day;
    TextView Nloker;

    int success;
    ConnectivityManager conMgr;
    SharedPreferences.Editor sharedpreferences;
    private String KEY_NAME = "NAMA";
    private String KEY_NO = "NO";
    private String KEY_LOKER = "LOKER";

    private String url = Server.URL + "/APICheck";

    private static final String TAG = RegisterTamuActivity.class.getSimpleName();

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    String tag_json_obj = "json_obj_req";
    ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_check_locker);

        cek = findViewById(R.id.btn_rent_a_locker_l1);
        Bloker = findViewById(R.id.UCLoker);
        Nloker = findViewById(R.id.txt_header_1_locker_L1);
        day = findViewById(R.id.txt_header_2_locker_L1);

        Bundle extras = getIntent().getExtras();
        no = extras.getString(KEY_NO);

        Bloker.setText("L"+no);
        Nloker.setText("Locker-"+no);

        cek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Bundle extras = getIntent().getExtras();
                name = extras.getString(KEY_NAME);
                lok = "l"+no+"pnj";
                cekLoker(no,name);
                //Toast.makeText(UserCheckLockerActivity.this,no+" - "+name,Toast.LENGTH_LONG).show();
            }
        });

        DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy");
        String date = df.format(Calendar.getInstance().getTime());

        day.setText(date);

    }

    private void cekLoker( final String loker, final String name){
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Check ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Check Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    success = jObj.getInt(TAG_SUCCESS);

                    // Check for error node in json
                    if (success == 1 || success == 2) {

                        sharedpreferences = getSharedPreferences("login",
                                UserCheckLockerActivity.MODE_PRIVATE).edit();
                        sharedpreferences.putString("aksi", "1");
                        sharedpreferences.putString("loker", no);
                        sharedpreferences.commit();

                        intent = new Intent(UserCheckLockerActivity.this, LockerL1V2Activity.class);
                        intent.putExtra(KEY_NAME,name);
                        finish();
                        startActivity(intent);

                    } else {
                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

                hideDialog();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("loker", loker);
                params.put("name", name);
                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_json_obj);
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }

}