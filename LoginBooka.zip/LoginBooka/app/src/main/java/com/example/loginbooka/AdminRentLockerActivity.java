package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class AdminRentLockerActivity extends AppCompatActivity {

    Button l1, l2, l3, l4;
    Intent intent;
    ImageView logout, presensi, info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_rent_locker);

        l1 = findViewById(R.id.btn_locker_1);

        logout = findViewById(R.id.logout);
        info = findViewById(R.id.info);
        presensi = findViewById(R.id.presensi);

        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               intent =  new Intent(AdminRentLockerActivity.this, TentangKamiActivity.class);
               finish();
               startActivity(intent);
            }
        });

        presensi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(AdminRentLockerActivity.this, AdminPresensiActivity.class);
                finish();
                startActivity(intent);
            }
        });

        l1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(AdminRentLockerActivity.this, AdminL1Activity.class);
                finish();
                startActivity(intent);
            }
        });
    }
}