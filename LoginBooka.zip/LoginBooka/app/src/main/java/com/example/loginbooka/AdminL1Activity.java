package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;

import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

public class AdminL1Activity extends ListActivity implements FetchDataListener{
    private ProgressDialog dialog;
    Button closed,opened;
    String lo;
    SharedPreferences sharedpreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_l1);
        initView();

        sharedpreferences = getSharedPreferences("login",
                Context.MODE_PRIVATE);
        // Toast.makeText(LockerL1V2Activity.this,sharedpreferences.getString("loker", ""),Toast.LENGTH_LONG).show();
        lo = sharedpreferences.getString("loker", "");

        DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy");
        String date = df.format(Calendar.getInstance().getTime());


        opened = findViewById(R.id.admin_open);
        closed = findViewById(R.id.admin_close);

        closed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataClose();
            }
        });
        opened.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataOpen();
            }
        });
    }

    private void initView() {
        // show progress dialog
//        dialog = ProgressDialog.show(this, "", "Loading...");

        String url = "http:// 192.168.1.5:8000/APIHistoryl1?loker=l1pnj";
//        String url = "http://192.168.100.2:8000/APIHistoryl1?loker=l1pnj";
        FetchDataTask task = new FetchDataTask(this);
        task.execute(url);
    }

    @Override
    public void onFetchComplete(List<Application> data) {
        // dismiss the progress dialog
        if(dialog != null)  dialog.dismiss();
        // create new adapter
        ApplicationAdapter adapter = new ApplicationAdapter(this, data);
        // set the adapter to list
        setListAdapter(adapter);
    }

    @Override
    public void onFetchFailure(String msg) {
        // dismiss the progress dialog
        if(dialog != null)  dialog.dismiss();
        // show failure message
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    void dataOpen() {
//        String bk = "0";
//
//        if(lo.equals("1")){
//            bk = "0";
//        } else if(lo.equals("2")){
//            bk = "10";
//        } else if(lo.equals("3")){
//            bk = "20";
//        } else if(lo.equals("4")){
//            bk = "30";
//        }
//
//        AndroidNetworking.get("http://192.168.4.1/?value="+bk)
//                .setTag("test")
//                .setPriority(Priority.MEDIUM)
//                .build()
//                .getAsJSONObject(new JSONObjectRequestListener() {
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        // do anything with response
//                    }
//
//                    @Override
//                    public void onError(ANError error) {
//                        // handle error
//                    }
//                });
        AndroidNetworking.get("http://192.168.4.1/?value=0")
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // do anything with response
                    }

                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }


    void dataClose() {
//        String tp = "0";
//
//        if(lo.equals("1")){
//            tp = "180";
//        } else if(lo.equals("2")){
//            tp = "170";
//        } else if(lo.equals("3")){
//            tp = "160";
//        } else if(lo.equals("4")){
//            tp = "150";
//        }
//        AndroidNetworking.get("http://192.168.4.1/?value="+tp)
//                .setTag("test")
//                .setPriority(Priority.MEDIUM)
//                .build()
//                .getAsJSONObject(new JSONObjectRequestListener() {
//                    @Override
//                    public void onResponse(JSONObject response) {
//                        // do anything with response
//                    }
//
//                    @Override
//                    public void onError(ANError error) {
//                        // handle error
//                    }
//                });
        AndroidNetworking.get("http://192.168.4.1/?value=180")
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // do anything with response
                    }

                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }

    @Override
    public void onBackPressed() {
        Intent setIntent = new Intent(AdminL1Activity.this, BerandaAdmin.class);
        finish();
        startActivity(setIntent);
    }
}