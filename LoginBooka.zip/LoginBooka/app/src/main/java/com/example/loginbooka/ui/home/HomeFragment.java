package com.example.loginbooka.ui.home;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.loginbooka.LockerL1Activity;
import com.example.loginbooka.LockerL2Activity;
import com.example.loginbooka.LockerL3Activity;
import com.example.loginbooka.LockerL4Activity;
import com.example.loginbooka.MainActivity;
import com.example.loginbooka.R;
import com.example.loginbooka.SignInActivity;
import com.example.loginbooka.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {
    private HomeViewModel homeViewModel;
    private FragmentHomeBinding binding;
    TextView txt_username;
    String username;
    SharedPreferences sharedpreferences;

    public static final String TAG_USERNAME = "name";
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);

        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

//        View view = inflater.inflate(R.layout.fragment_home, container, false);
        Button btn_locker_1 = (Button) root.findViewById(R.id.btn_locker_1);
        Button btn_locker_2 = (Button) root.findViewById(R.id.btn_locker_2);
        Button btn_locker_3 = (Button) root.findViewById(R.id.btn_locker_3);
        Button btn_locker_4 = (Button) root.findViewById(R.id.btn_locker_4);

        btn_locker_1.setOnClickListener(v -> startActivity(new Intent(getActivity(), LockerL1Activity.class)));

        btn_locker_2.setOnClickListener(v -> startActivity(new Intent(getActivity(), LockerL2Activity.class)));

        btn_locker_3.setOnClickListener(v -> startActivity(new Intent(getActivity(), LockerL3Activity.class)));

        btn_locker_4.setOnClickListener(v -> startActivity(new Intent(getActivity(), LockerL4Activity.class)));

        final TextView textView = binding.textHome;
        homeViewModel.getText().observe(getViewLifecycleOwner(), s -> textView.setText(s));

        txt_username = (TextView) root.findViewById(R.id.text_name);

        sharedpreferences = getActivity().getSharedPreferences(SignInActivity.my_shared_preferences, Context.MODE_PRIVATE);

        username = getActivity().getIntent().getStringExtra(TAG_USERNAME);

        txt_username.setText(username);

//        btn_logout.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                // TODO Auto-generated method stub
//                // update login session ke FALSE dan mengosongkan nilai id dan username
//                SharedPreferences.Editor editor = sharedpreferences.edit();
//                editor.putBoolean(Login.session_status, false);
//                editor.putString(TAG_ID, null);
//                editor.putString(TAG_USERNAME, null);
//                editor.commit();
//
//                Intent intent = new Intent(MainActivity.this, Login.class);
//                finish();
//                startActivity(intent);
//            }
//        });
        return root;

//        return view;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}