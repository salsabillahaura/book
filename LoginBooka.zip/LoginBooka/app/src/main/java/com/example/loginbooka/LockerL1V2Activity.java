package com.example.loginbooka;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.androidnetworking.interfaces.StringRequestListener;
import com.example.loginbooka.app.AppController;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;


public class LockerL1V2Activity extends AppCompatActivity {
    Button open, close, finish;
    int success;
    ConnectivityManager conMgr;
    String lo,nm;
    AppCompatButton Bloker;
    TextView Nloker;
    TextView day;
    private String KEY_NAME = "NAMA";
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor sharedpreferencesup;

    private String url = Server.URL + "/APIFinish";

    private static final String TAG = RegisterTamuActivity.class.getSimpleName();

    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";

    String tag_json_obj = "json_obj_req";
    ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        open = findViewById(R.id.btn_open_locker_l1);
        close = findViewById(R.id.btn_close_locker_l1);
        finish = findViewById(R.id.btn_finish_locker_l1);
        Bloker = findViewById(R.id.btn_l1);
        Nloker = findViewById(R.id.txt_header_1_locker_L1);
        day = findViewById(R.id.txt_header_2_locker_L1);

        sharedpreferences = getSharedPreferences("login",
                Context.MODE_PRIVATE);
       // Toast.makeText(LockerL1V2Activity.this,sharedpreferences.getString("loker", ""),Toast.LENGTH_LONG).show();
        lo = sharedpreferences.getString("loker", "");
        nm = sharedpreferences.getString("name", "");
        Bloker.setText("L"+lo);
        Nloker.setText("Locker-"+lo);

        DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy");
        String date = df.format(Calendar.getInstance().getTime());

        day.setText(date);

        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataClose();
            }
        });
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dataOpen();
            }
        });
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle extras = getIntent().getExtras();
                //String name = extras.getString(KEY_NAME);
                String loker = "l1pnj";
                selesaipinjam(lo,nm);
            }
        });

    }

    private void selesaipinjam( final String loker, final String name){
        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        pDialog.setMessage("Check ...");
        showDialog();

        StringRequest strReq = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.e(TAG, "Check Response: " + response.toString());
                hideDialog();

                try {
                    JSONObject jObj = new JSONObject(response);
                    success = jObj.getInt(TAG_SUCCESS);

                    // Check for error node in json
                    if (success == 1 ) {
                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                        sharedpreferencesup = getSharedPreferences("login",
                                UserCheckLockerActivity.MODE_PRIVATE).edit();
                        sharedpreferencesup.putString("aksi", "0");
                        sharedpreferencesup.commit();

                        Intent intent = new Intent(LockerL1V2Activity.this, BerandaUsers.class);
                        intent.putExtra("name", sharedpreferences.getString("name", ""));
                        finish();
                        startActivity(intent);
                    } else {
                        Toast.makeText(getApplicationContext(),
                                jObj.getString(TAG_MESSAGE), Toast.LENGTH_LONG).show();

                    }
                } catch (JSONException e) {
                    // JSON error
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "Login Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(),
                        error.getMessage(), Toast.LENGTH_LONG).show();

                hideDialog();

            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                // Posting parameters to login url
                Map<String, String> params = new HashMap<String, String>();
                params.put("loker", loker);
                params.put("name", name);
                return params;
            }

        };

        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(strReq, tag_json_obj);
    }

    void dataOpen() {
        String bk = "0";

        if(lo.equals("1")){
            bk = "0";
        } else if(lo.equals("2")){
            bk = "10";
        } else if(lo.equals("3")){
            bk = "20";
        } else if(lo.equals("4")){
            bk = "30";
        }

        AndroidNetworking.get("http://192.168.4.1/?value="+bk)
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // do anything with response
                    }

                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }


    void dataClose() {
        String tp = "0";

        if(lo.equals("1")){
            tp = "180";
        } else if(lo.equals("2")){
            tp = "170";
        } else if(lo.equals("3")){
            tp = "160";
        } else if(lo.equals("4")){
            tp = "150";
        }
        AndroidNetworking.get("http://192.168.4.1/?value="+tp)
                .setTag("test")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        // do anything with response
                    }

                    @Override
                    public void onError(ANError error) {
                        // handle error
                    }
                });
    }
    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
}