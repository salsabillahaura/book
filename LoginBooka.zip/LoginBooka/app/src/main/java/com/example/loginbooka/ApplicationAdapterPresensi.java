package com.example.loginbooka;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.List;

public class ApplicationAdapterPresensi extends ArrayAdapter<ApplicationPresensi> {
    private List<ApplicationPresensi> items;

    public ApplicationAdapterPresensi(Context context, List<ApplicationPresensi> items) {
        super(context, R.layout.app_custom_presensi_list, items);
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;

        if(v == null) {
            LayoutInflater li = LayoutInflater.from(getContext());
            v = li.inflate(R.layout.app_custom_presensi_list, null);
        }

        ApplicationPresensi app = items.get(position);

        if(app != null) {
            TextView titleText = (TextView)v.findViewById(R.id.name);
            TextView dlText = (TextView)v.findViewById(R.id.date);

            if(titleText != null) titleText.setText(app.getTextPresensi());
            if(dlText != null) dlText.setText("masuk pada tanggal " + app.getDateLogin());


        }

        return v;
    }
}
