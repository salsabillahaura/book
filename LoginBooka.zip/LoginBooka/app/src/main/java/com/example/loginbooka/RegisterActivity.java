package com.example.loginbooka;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Button btn_mahasiswa = (Button)findViewById(R.id.btn_mahasiswa_pnj);
        Button btn_dosen = (Button)findViewById(R.id.btn_dosen_pnj);
        Button btn_tamu = (Button)findViewById(R.id.btn_tamu);

        btn_mahasiswa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, RegisterMahasiswaActivity.class));
            }
        });

        btn_dosen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, RegisterDosenActivity.class));
            }
        });

        btn_tamu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this, RegisterTamuActivity.class));
            }
        });

    }
}